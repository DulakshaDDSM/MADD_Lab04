package com.example.madd_lab04

data class Todo(
    var id: Int,
    var title: String
)

